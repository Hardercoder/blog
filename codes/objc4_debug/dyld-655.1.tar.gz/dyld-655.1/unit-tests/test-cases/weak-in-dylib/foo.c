




int __attribute__((weak)) foo[] = { 1, 2, 3, 4 };

