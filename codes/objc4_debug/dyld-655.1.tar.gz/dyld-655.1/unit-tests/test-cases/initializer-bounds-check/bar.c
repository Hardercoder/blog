
int bar = 0;

void altSecondInit()
{
	bar = 1;
}
