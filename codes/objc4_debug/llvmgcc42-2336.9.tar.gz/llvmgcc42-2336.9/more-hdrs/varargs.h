/* This file is public domain.  */
#ifdef __MWERKS__
#include "mw_varargs.h"
#else
#error "This header only supports __MWERKS__."
#endif
