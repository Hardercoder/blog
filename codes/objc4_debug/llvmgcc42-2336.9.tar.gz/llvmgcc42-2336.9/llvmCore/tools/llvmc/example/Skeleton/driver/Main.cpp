//===--- Main.cpp - The LLVM Compiler Driver -------------------*- C++ -*-===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open
// Source License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
//  Just include CompilerDriver/Main.inc.
//
//===----------------------------------------------------------------------===//

#include "llvm/CompilerDriver/Main.inc"
