"""'lit' Testing Tool"""

from lit import main

__author__ = 'Daniel Dunbar'
__email__ = 'daniel@zuster.org'
__versioninfo__ = (0, 1, 0)
__version__ = '.'.join(map(str, __versioninfo__))

__all__ = []
