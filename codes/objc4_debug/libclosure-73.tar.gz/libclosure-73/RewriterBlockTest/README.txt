This is a basic test of blocks on windows.

To use:

- modify the simpleblock.c file accordingly (or make a new one)

- run the clang command line as specified in that source file

- open the Visual Studio project

- open the resulting .cpp file and uncomment various commented out bits

- attempt to compile and run

Assumes that AppleInternal has been populated and the libclosure project has been built.
